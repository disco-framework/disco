#!/bin/bash

read numbers
read result

sleep .2
echo "1 * (2 + 40)"
sleep .3
echo "4 + (1 * (40 - 2))"
sleep .3
echo "1 * (4 + (40 - 2))"
sleep .6
echo "(4 + (1 * 40)) - 2"
sleep 1
echo "1 * ((4 + 40) - 2)"
sleep 2
echo "(1 * (4 + 40)) - 2"
sleep 4

#!/bin/bash

read squares
read n

echo "[]"
sleep .2
echo "[(0,0,2)]"
sleep .2
echo "[(0,0,4)]"
sleep .2
echo "[(0,0,4),(4,0,2)]"
sleep .2
echo "[(0,0,40)]"
sleep .2
echo "[(0,0,40),(40,0,2)]"
sleep 5
